<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('radio_buttons', function (Blueprint $table) {
            $table->id();
            $table->integer('field_id')->nullable();
            $table->string('option_question')->nullable();
            $table->string('x')->nullable();
            $table->string('y')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('radio_buttons');
    }
};
