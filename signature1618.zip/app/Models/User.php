<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'user_role',
        'status',
        'phone',
        'language',
        'username',
        'company',
        'last_name',
        'unique_id',
        'google_id',
        'is_verified',
        'contact_type',
        'promo_used',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function subscriptionDetail()
    {
        return $this->hasOne(Subscription::class, 'user_id');
    }

    public function requestLogs()
    {
        return $this->hasMany(RequestLog::class, 'user_email', 'email');
    }
    
    public function aiActivities()
    {
        return $this->hasMany(AIActivity::class);
    }
}
