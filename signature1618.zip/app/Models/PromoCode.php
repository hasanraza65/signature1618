<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PromoCode extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function generatedBy(){
        return $this->belongsTo(User::class,'generated_by');
    }
}
