<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\User;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiKeyMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle($request, Closure $next)
    {
        $authHeader = $request->header('Authorization');

        if (!$authHeader || !str_starts_with($authHeader, 'Bearer ')) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $secret = str_replace('Bearer ', '', $authHeader);

        $user = User::where('api_secret', $secret)->first();

        if (!$user) {
            return response()->json(['message' => 'Invalid API Secret'], 403);
        }

        // attach user for later use
        $request->merge(['api_user' => $user]);

        return $next($request);
    }
}
